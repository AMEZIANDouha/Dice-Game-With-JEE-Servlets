package com.dn;

public class Dice {
    private int dice1;
    private int dice2;
    private int dice3;


    public Dice(){}
    public int getDice1() {
        return dice1;
    }
    public int getDice2() {
        return dice2;
    }
    public int getDice3() {
        return dice3;
    }

    public int setDice1(int dice1) {
        this.dice1 = dice1;
        return dice1;
    }
    public int setDice2(int dice1) {
        this.dice2 = dice1;
        return dice1;
    }
    public int setDice3(int dice1) {
        this.dice3 = dice1;
        return dice1;
    }

}
