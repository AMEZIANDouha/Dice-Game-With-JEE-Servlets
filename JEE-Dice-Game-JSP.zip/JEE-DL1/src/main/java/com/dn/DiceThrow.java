package com.dn;

public class DiceThrow {
    private int diceNumber;
    private int result;

    public DiceThrow(int diceNumber, int result) {
        this.diceNumber = diceNumber;
        this.result = result;
    }

    public int getDiceNumber() {
        return diceNumber;
    }

    public void setDiceNumber(int diceNumber) {
        this.diceNumber = diceNumber;
    }

    public int getResult() {
        return result;
    }

    public void setResult(int result) {
        this.result = result;
    }
}
