package com.web.servlets;

import com.dn.User;
import com.web.helpers.GameContextManagement;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

@WebServlet("/back/bestScore")
public class BestScoreServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		GameContextManagement gameContext = GameContextManagement.getInstance(getServletContext());

		// Get all users from the context
		List<User> users = gameContext.getAllUsers();

		// Set the list of users as an attribute to be accessed in the JSP
		request.setAttribute("users", users);

		// Forward the request to the best score page
		getServletContext().getRequestDispatcher("/WEB-INF/vues/back/bestScore.jsp").forward(request, response);
	}
}