package com.web.servlets;

import com.dn.*;
import com.web.helpers.GameContextManagement;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@WebServlet("/back/GameServlet")
public class GameServlet extends HttpServlet {

    protected void play(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get the session and user details
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        GameContextManagement gameContext = GameContextManagement.getInstance(getServletContext());
        GameState gameState = (GameState) session.getAttribute("gameState");

        // Get the last thrown dice value and list of thrown dices
        Integer lastThrownDice = (Integer) session.getAttribute("lastThrownDice");
        List<DiceThrow> thrownDices = (List<DiceThrow>) session.getAttribute("thrownDices");

        // Initialize the list if it's null
        if (thrownDices == null) {
            thrownDices = new ArrayList<>();
            session.setAttribute("thrownDices", thrownDices);
        }

        // Check if the game is already over
        if (gameState.isGameOver()) {
            getServletContext().getRequestDispatcher("/WEB-INF/vues/back/userHome.jsp").forward(request, response);
            return;
        }

        // Get the selected value of the current dice throw
        int selectedValue = Integer.parseInt(request.getParameter("diceNumber"));
        user.setDicenumber(selectedValue);

        // Check if the selected value has already been thrown
        for (DiceThrow diceThrow : thrownDices) {
            if (diceThrow.getDiceNumber() == selectedValue) {
                if (!gameState.isGameOver()) {
                    gameState.addMessage(new Message("Game Over - Same dice thrown again", Message.INFO));
                    gameState.setGameOver(true);
                    user.setScore(-1);
                    getServletContext().getRequestDispatcher("/WEB-INF/vues/back/userHome.jsp").forward(request, response);
                    return;
                }
            }
        }

        // Store the value of the current dice throw
        session.setAttribute("lastThrownDice", selectedValue);
        int result = 1 + new Random().nextInt(6);
        DiceThrow currentDiceThrow = new DiceThrow(selectedValue, result);
        thrownDices.add(currentDiceThrow);
        gameState.addMessage(new Message(String.valueOf(result), Message.INFO));
        user.incrementLance();

        if (user.getCompteurLancer() == 1 || user.getCompteurLancer() == 2) {
            if (result == 6){
                user.setScore(0);
                gameState.setGameOver(true);
                gameState.addMessage(new Message("Félicitations ! C'est gagné !! " , Message.INFO));
            }}


        // Check if the user has completed three dice throws
        if (user.getCompteurLancer() >= 3) {
            // Calculate the score based on the dice throws
            int dice1Result = thrownDices.get(0).getResult();
            int dice2Result = thrownDices.get(1).getResult();
            int dice3Result = thrownDices.get(2).getResult();

            // Check if the conditions for calculating the score are met
            if (dice1Result < dice2Result && dice2Result < dice3Result) {
                int totalScore = dice1Result + dice2Result + dice3Result;
                user.setScore(totalScore);
                gameState.addMessage(new Message("Game Over ! check your score !!", Message.INFO));
            } else {
                user.setScore(0);
                gameState.addMessage(new Message("Game over !! ", Message.INFO));
            }

            // Check if the user's score is greater than their best score
            if (user.getScore() > user.getBestScore()) {
                // If yes, update the best score
                user.setBestScore(user.getScore());
                gameContext.updateScore(user);
            }

            // End the game
            gameState.setGameOver(true);
            getServletContext().getRequestDispatcher("/WEB-INF/vues/back/userHome.jsp").forward(request, response);
            return;
        }

        // Forward the request to the user home page
        getServletContext().getRequestDispatcher("/WEB-INF/vues/back/userHome.jsp").forward(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        play(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        play(request, response);
    }
}