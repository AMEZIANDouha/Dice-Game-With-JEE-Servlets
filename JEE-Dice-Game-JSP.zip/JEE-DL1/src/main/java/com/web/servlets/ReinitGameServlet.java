package com.web.servlets;

import com.dn.GameState;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.List;

@WebServlet("/back/ReinitGameServlet")
public class ReinitGameServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession();

		GameState gs = (GameState) session.getAttribute("gameState");

		if (gs != null) {
			// Retrieve the best score from the user object within the game state
			int bestScore = (int) gs.getUser().getBestScore();
			// Reinitialize the game state
			gs.reinit();
			// Restore the best score to the user object within the game state
			gs.getUser().setBestScore(bestScore);
		}

		// Réinitialisation de la liste des dés lancés
		List<Integer> thrownDices = (List<Integer>) session.getAttribute("thrownDices");
		if (thrownDices != null) {
			thrownDices.clear(); // Vider la liste des dés lancés
		}

		// reinit old result avec une valeur impossible pour le dé
		session.setAttribute("lastThrownDice", -1);


		getServletContext().getRequestDispatcher("/WEB-INF/vues/back/userHome.jsp").forward(request, response);

		return;

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

}
